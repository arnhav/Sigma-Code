package com.ftdi.j2xx.ft4222;

/* renamed from: com.ftdi.j2xx.ft4222.d */
class C0007d {
    C0006c f80a;
    byte f81b;
    byte f82c;
    byte[] f83d;

    public C0007d() {
        this.f80a = new C0006c();
        this.f83d = new byte[1];
    }
}
