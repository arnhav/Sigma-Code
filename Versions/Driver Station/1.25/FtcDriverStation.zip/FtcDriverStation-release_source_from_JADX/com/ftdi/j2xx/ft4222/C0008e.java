package com.ftdi.j2xx.ft4222;

/* renamed from: com.ftdi.j2xx.ft4222.e */
class C0008e {
    int[] f84a;
    int[] f85b;
    byte f86c;

    public C0008e() {
        this.f84a = new int[4];
        this.f85b = new int[4];
    }
}
