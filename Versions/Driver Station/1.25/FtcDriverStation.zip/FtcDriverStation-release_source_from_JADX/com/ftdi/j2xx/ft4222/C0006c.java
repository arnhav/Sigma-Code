package com.ftdi.j2xx.ft4222;

/* renamed from: com.ftdi.j2xx.ft4222.c */
class C0006c {
    byte f77a;
    byte f78b;
    byte[] f79c;

    public C0006c() {
        this.f79c = new byte[3];
    }
}
