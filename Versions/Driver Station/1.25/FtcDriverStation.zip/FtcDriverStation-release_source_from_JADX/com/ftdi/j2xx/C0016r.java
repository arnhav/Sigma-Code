package com.ftdi.j2xx;

/* renamed from: com.ftdi.j2xx.r */
class C0016r {
    public byte f141a;
    public byte f142b;
    public byte f143c;
    public byte f144d;

    C0016r() {
    }
}
