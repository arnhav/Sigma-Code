package com.ftdi.j2xx;

/* renamed from: com.ftdi.j2xx.q */
class C0015q {
    public long f140a;

    C0015q() {
    }
}
