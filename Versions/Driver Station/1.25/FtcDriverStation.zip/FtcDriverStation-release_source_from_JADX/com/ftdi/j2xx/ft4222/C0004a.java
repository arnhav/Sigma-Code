package com.ftdi.j2xx.ft4222;

/* renamed from: com.ftdi.j2xx.ft4222.a */
class C0004a {
    int f61a;
    int f62b;
    int f63c;
    int f64d;
    byte f65e;
}
