package com.qualcomm.robotcore.hardware;

public interface VoltageSensor extends HardwareDevice {
    double getVoltage();
}
