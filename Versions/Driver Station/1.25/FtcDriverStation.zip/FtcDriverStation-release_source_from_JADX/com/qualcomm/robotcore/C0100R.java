package com.qualcomm.robotcore;

/* renamed from: com.qualcomm.robotcore.R */
public final class C0100R {

    /* renamed from: com.qualcomm.robotcore.R.color */
    public static final class color {
        public static final int black = 2131296256;
        public static final int bright_red = 2131296258;
        public static final int bright_red_text = 2131296259;
        public static final int dark_red_background = 2131296260;
        public static final int light_red_background = 2131296262;
        public static final int medium_red_background = 2131296264;
        public static final int transparent_color = 2131296265;
        public static final int very_bright_red = 2131296266;
        public static final int white = 2131296267;
    }

    /* renamed from: com.qualcomm.robotcore.R.string */
    public static final class string {
        public static final int app_name = 2131361800;
    }

    /* renamed from: com.qualcomm.robotcore.R.style */
    public static final class style {
        public static final int AppBaseTheme = 2131165184;
        public static final int AppTheme = 2131165185;
    }
}
