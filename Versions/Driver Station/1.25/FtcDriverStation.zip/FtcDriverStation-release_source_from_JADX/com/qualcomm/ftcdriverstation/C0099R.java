package com.qualcomm.ftcdriverstation;

/* renamed from: com.qualcomm.ftcdriverstation.R */
public final class C0099R {

    /* renamed from: com.qualcomm.ftcdriverstation.R.anim */
    public static final class anim {
        public static final int fadein = 2130968576;
        public static final int fadeout = 2130968577;
    }

    /* renamed from: com.qualcomm.ftcdriverstation.R.array */
    public static final class array {
        public static final int choice_array = 2131230720;
        public static final int choice_array_analogInput = 2131230721;
        public static final int choice_array_analogOutput = 2131230722;
        public static final int choice_array_digital_device = 2131230723;
        public static final int choice_array_i2c = 2131230724;
        public static final int device_interface_module_options_array = 2131230725;
        public static final int pref_gamepad_type_entries = 2131230726;
        public static final int wifi_direct_channels = 2131230727;
    }

    /* renamed from: com.qualcomm.ftcdriverstation.R.attr */
    public static final class attr {
    }

    /* renamed from: com.qualcomm.ftcdriverstation.R.color */
    public static final class color {
        public static final int black = 2131296256;
        public static final int bright_qcom_blue = 2131296257;
        public static final int bright_red = 2131296258;
        public static final int bright_red_text = 2131296259;
        public static final int dark_red_background = 2131296260;
        public static final int light_qcom_blue = 2131296261;
        public static final int light_red_background = 2131296262;
        public static final int medium_qcom_blue = 2131296263;
        public static final int medium_red_background = 2131296264;
        public static final int transparent_color = 2131296265;
        public static final int very_bright_red = 2131296266;
        public static final int white = 2131296267;
    }

    /* renamed from: com.qualcomm.ftcdriverstation.R.dimen */
    public static final class dimen {
        public static final int activity_horizontal_margin = 2131099648;
        public static final int activity_vertical_margin = 2131099649;
    }

    /* renamed from: com.qualcomm.ftcdriverstation.R.drawable */
    public static final class drawable {
        public static final int button_shape = 2130837504;
        public static final int circles = 2130837505;
        public static final int controlpanel_back = 2130837506;
        public static final int ic_launcher = 2130837507;
        public static final int icon_arrow = 2130837508;
        public static final int icon_battery0 = 2130837509;
        public static final int icon_battery100 = 2130837510;
        public static final int icon_battery25 = 2130837511;
        public static final int icon_battery50 = 2130837512;
        public static final int icon_battery75 = 2130837513;
        public static final int icon_controller = 2130837514;
        public static final int icon_controlleractive = 2130837515;
        public static final int icon_init = 2130837516;
        public static final int icon_menu = 2130837517;
        public static final int icon_play = 2130837518;
        public static final int icon_robotcontroller = 2130837519;
        public static final int icon_stop = 2130837520;
        public static final int icon_timeroff = 2130837521;
        public static final int icon_timeron = 2130837522;
        public static final int icon_voltage = 2130837523;
    }

    /* renamed from: com.qualcomm.ftcdriverstation.R.id */
    public static final class id {
        public static final int DS_battery_icon = 2131492887;
        public static final int aboutList = 2131492864;
        public static final int action_about = 2131493097;
        public static final int action_exit_app = 2131493098;
        public static final int action_restart_robot = 2131493096;
        public static final int action_settings = 2131493095;
        public static final int active_filename = 2131492997;
        public static final int activity_fix_misconfig_wifi_direct = 2131492869;
        public static final int analogOutput_devices_cancelButton = 2131492960;
        public static final int analogOutput_devices_saveButton = 2131492959;
        public static final int analog_input_devices_cancelButton = 2131492941;
        public static final int analog_input_devices_saveButton = 2131492940;
        public static final int attached_title = 2131492945;
        public static final int autoconfigure = 2131492932;
        public static final int autoconfigure_holder = 2131492931;
        public static final int autoconfigure_info = 2131492868;
        public static final int battery_info_layout = 2131492902;
        public static final int buttonConfigure = 2131492923;
        public static final int buttonInit = 2131492911;
        public static final int buttonInitStop = 2131492915;
        public static final int buttonSelect = 2131492907;
        public static final int buttonStart = 2131492910;
        public static final int buttonStartTimed = 2131492913;
        public static final int buttonStart_frame = 2131492909;
        public static final int buttonStop = 2131492912;
        public static final int buttonWifiSettings = 2131492924;
        public static final int checkbox_port6 = 2131493061;
        public static final int checkbox_port7 = 2131493058;
        public static final int checkbox_port_matrix = 2131493049;
        public static final int checkbox_port_pwm = 2131493069;
        public static final int checkbox_port_servo = 2131493076;
        public static final int choiceSpinner_analogInput = 2131492937;
        public static final int choiceSpinner_analogOutput = 2131492956;
        public static final int choiceSpinner_digital_device = 2131492974;
        public static final int choiceSpinner_i2c = 2131493000;
        public static final int choiceSpinner_legacyModule = 2131493092;
        public static final int circle_ping = 2131492899;
        public static final int circle_wifi = 2131492896;
        public static final int configureLegacy = 2131492867;
        public static final int configureUSB = 2131492866;
        public static final int controlPanel = 2131492908;
        public static final int controller_name = 2131493054;
        public static final int controller_name_text = 2131493014;
        public static final int controllers = 2131492996;
        public static final int controllersList = 2131492878;
        public static final int custom_title_bar = 2131492964;
        public static final int device_interface_module_cancelButton = 2131492966;
        public static final int device_interface_module_name = 2131492967;
        public static final int device_interface_module_saveButton = 2131492965;
        public static final int device_interface_module_serialNumber = 2131492968;
        public static final int devices_holder = 2131492876;
        public static final int devices_info_btn = 2131492877;
        public static final int digital_devices_cancelButton = 2131492978;
        public static final int digital_devices_saveButton = 2131492977;
        public static final int dropdown_layout = 2131493091;
        public static final int dsBatteryInfo = 2131492888;
        public static final int editTextResult_analogInput = 2131492938;
        public static final int editTextResult_analogInput6 = 2131493062;
        public static final int editTextResult_analogInput7 = 2131493059;
        public static final int editTextResult_analogOutput = 2131492957;
        public static final int editTextResult_digital_device = 2131492975;
        public static final int editTextResult_i2c = 2131493001;
        public static final int editTextResult_matrix = 2131493050;
        public static final int editTextResult_name = 2131493093;
        public static final int editTextResult_pwm = 2131493070;
        public static final int editTextResult_servo = 2131493077;
        public static final int edit_controller_btn = 2131493094;
        public static final int empty_devicelist = 2131492879;
        public static final int empty_filelist = 2131492930;
        public static final int file_activate_button = 2131492994;
        public static final int file_buttons = 2131492989;
        public static final int file_delete_button = 2131492995;
        public static final int file_edit_button = 2131492993;
        public static final int file_info_layout = 2131492988;
        public static final int filename_editText = 2131492991;
        public static final int files_holder = 2131492928;
        public static final int header = 2131492970;
        public static final int holdsDevices = 2131492871;
        public static final int holds_buttons = 2131492926;
        public static final int horizontalButtons = 2131492992;
        public static final int i2c_devices_cancelButton = 2131493004;
        public static final int i2c_devices_saveButton = 2131493003;
        public static final int included_header = 2131492865;
        public static final int inclusionlayout = 2131492929;
        public static final int info_btn = 2131493012;
        public static final int legacy_serialNumber = 2131493013;
        public static final int linearLayout = 2131492990;
        public static final int linearLayout0 = 2131493018;
        public static final int linearLayout1 = 2131493021;
        public static final int linearLayout2 = 2131493024;
        public static final int linearLayout3 = 2131493027;
        public static final int linearLayout4 = 2131493030;
        public static final int linearLayout5 = 2131493033;
        public static final int linearLayout_analogInput0 = 2131492953;
        public static final int linearLayout_analogInput1 = 2131492952;
        public static final int linearLayout_analogInput2 = 2131492951;
        public static final int linearLayout_analogInput3 = 2131492950;
        public static final int linearLayout_analogInput4 = 2131492949;
        public static final int linearLayout_analogInput5 = 2131492948;
        public static final int linearLayout_analogInput6 = 2131492947;
        public static final int linearLayout_analogInput7 = 2131492946;
        public static final int linearLayout_analogOutput0 = 2131492963;
        public static final int linearLayout_analogOutput1 = 2131492962;
        public static final int linearLayout_digital_device0 = 2131492987;
        public static final int linearLayout_digital_device1 = 2131492986;
        public static final int linearLayout_digital_device2 = 2131492985;
        public static final int linearLayout_digital_device3 = 2131492984;
        public static final int linearLayout_digital_device4 = 2131492983;
        public static final int linearLayout_digital_device5 = 2131492982;
        public static final int linearLayout_digital_device6 = 2131492981;
        public static final int linearLayout_digital_device7 = 2131492980;
        public static final int linearLayout_i2c0 = 2131493011;
        public static final int linearLayout_i2c1 = 2131493010;
        public static final int linearLayout_i2c2 = 2131493009;
        public static final int linearLayout_i2c3 = 2131493008;
        public static final int linearLayout_i2c4 = 2131493007;
        public static final int linearLayout_i2c5 = 2131493006;
        public static final int linearLayout_matrix1 = 2131493038;
        public static final int linearLayout_matrix2 = 2131493039;
        public static final int linearLayout_matrix3 = 2131493040;
        public static final int linearLayout_matrix4 = 2131493041;
        public static final int linearLayout_matrix5 = 2131493043;
        public static final int linearLayout_matrix6 = 2131493044;
        public static final int linearLayout_matrix7 = 2131493045;
        public static final int linearLayout_matrix8 = 2131493046;
        public static final int linearLayout_pwm0 = 2131493073;
        public static final int linearLayout_pwm1 = 2131493072;
        public static final int linearLayout_servo1 = 2131493083;
        public static final int linearLayout_servo2 = 2131493084;
        public static final int linearLayout_servo3 = 2131493085;
        public static final int linearLayout_servo4 = 2131493086;
        public static final int linearLayout_servo5 = 2131493087;
        public static final int linearLayout_servo6 = 2131493088;
        public static final int listView_devices = 2131492969;
        public static final int load_bottom = 2131492925;
        public static final int matrix_controller_cancelButton = 2131493035;
        public static final int matrix_controller_saveButton = 2131493034;
        public static final int matrixcontroller_name = 2131493036;
        public static final int menu_buttons = 2131492889;
        public static final int motor_controller_serialNumber = 2131493055;
        public static final int motors_title = 2131493042;
        public static final int new_button = 2131492927;
        public static final int orange_warning = 2131493064;
        public static final int orangetext0 = 2131493065;
        public static final int orangetext1 = 2131493066;
        public static final int ping = 2131492900;
        public static final int port0 = 2131493017;
        public static final int port1 = 2131493020;
        public static final int port2 = 2131493023;
        public static final int port3 = 2131493026;
        public static final int port4 = 2131493029;
        public static final int port5 = 2131493032;
        public static final int port7 = 2131493057;
        public static final int portNumber = 2131493090;
        public static final int port_number_analogInput = 2131492936;
        public static final int port_number_analogOutput = 2131492955;
        public static final int port_number_digital_device = 2131492973;
        public static final int port_number_i2c = 2131492999;
        public static final int port_number_matrix = 2131493048;
        public static final int port_number_pwm = 2131493068;
        public static final int port_number_servo = 2131493075;
        public static final int port_title = 2131492944;
        public static final int pwm_devices_cancelButton = 2131493053;
        public static final int pwm_devices_saveButton = 2131493052;
        public static final int radioGroupDevices = 2131492921;
        public static final int rcBatteryTelemetry = 2131492904;
        public static final int rc_battery_icon = 2131492903;
        public static final int robotBatteryTelemetry = 2131492906;
        public static final int robot_battery_icon = 2131492905;
        public static final int robot_logo = 2131492895;
        public static final int row_port = 2131493056;
        public static final int row_port0 = 2131493016;
        public static final int row_port1 = 2131493019;
        public static final int row_port2 = 2131493022;
        public static final int row_port3 = 2131493025;
        public static final int row_port4 = 2131493028;
        public static final int row_port5 = 2131493031;
        public static final int row_port_analogInput = 2131492935;
        public static final int row_port_analogOutput = 2131492954;
        public static final int row_port_digital_device = 2131492972;
        public static final int row_port_i2c = 2131492998;
        public static final int row_port_matrix = 2131493047;
        public static final int row_port_pwm = 2131493067;
        public static final int row_port_servo = 2131493074;
        public static final int save_config_btn = 2131492882;
        public static final int save_holder = 2131492880;
        public static final int scanButton = 2131492873;
        public static final int scanButton_text = 2131492874;
        public static final int scan_bottom = 2131492872;
        public static final int scrollView = 2131492933;
        public static final int scrollView1 = 2131492920;
        public static final int scrollViewLayout = 2131492884;
        public static final int servo_controller_cancelButton = 2131493080;
        public static final int servo_controller_saveButton = 2131493079;
        public static final int servo_controller_serialNumber = 2131493082;
        public static final int servocontroller_name = 2131493081;
        public static final int servos_title = 2131493037;
        public static final int shape = 2131493089;
        public static final int spinnerChannelSelect = 2131492922;
        public static final int tableLayout_analogOutput_devices = 2131492961;
        public static final int tableLayout_analog_input_devices = 2131492942;
        public static final int tableLayout_digital_devices = 2131492979;
        public static final int tableLayout_i2c_devices = 2131493005;
        public static final int tableLayout_pwm_devices = 2131493015;
        public static final int table_header = 2131492943;
        public static final int textAdbLogs = 2131492934;
        public static final int textDeviceName = 2131492886;
        public static final int textPingStatus = 2131492901;
        public static final int textSystemTelemetry = 2131492916;
        public static final int textTelemetry = 2131492917;
        public static final int textTimer = 2131492914;
        public static final int textView = 2131492870;
        public static final int textView1 = 2131492971;
        public static final int textWifiDirectDevices = 2131492919;
        public static final int textWifiDirectInstructions = 2131492918;
        public static final int textWifiDirectStatus = 2131492898;
        public static final int titleTextView_analogInput = 2131492939;
        public static final int titleTextView_analogInput7 = 2131493060;
        public static final int titleTextView_analogOutput = 2131492958;
        public static final int titleTextView_digital_device = 2131492976;
        public static final int titleTextView_i2c = 2131493002;
        public static final int titleTextView_matrix = 2131493051;
        public static final int titleTextView_motor2 = 2131493063;
        public static final int titleTextView_pwm = 2131493071;
        public static final int titleTextView_servo = 2131493078;
        public static final int top_bar = 2131492885;
        public static final int user1_icon_base = 2131492893;
        public static final int user1_icon_clicked = 2131492892;
        public static final int user2_icon_base = 2131492891;
        public static final int user2_icon_clicked = 2131492890;
        public static final int warning_layout = 2131492875;
        public static final int wifiDirect = 2131492897;
        public static final int wifi_info_layout = 2131492894;
        public static final int writeXML = 2131492881;
        public static final int writeXML_text = 2131492883;
    }

    /* renamed from: com.qualcomm.ftcdriverstation.R.layout */
    public static final class layout {
        public static final int activity_about = 2130903040;
        public static final int activity_autoconfigure = 2130903041;
        public static final int activity_config_wifi_direct = 2130903042;
        public static final int activity_ftc_configuration = 2130903043;
        public static final int activity_ftc_driver_station = 2130903044;
        public static final int activity_ftc_pair_wifi_direct = 2130903045;
        public static final int activity_ftc_wifi_channel_selector = 2130903046;
        public static final int activity_load = 2130903047;
        public static final int activity_settings = 2130903048;
        public static final int activity_view_logs = 2130903049;
        public static final int analog_input_device = 2130903050;
        public static final int analog_inputs = 2130903051;
        public static final int analog_output_device = 2130903052;
        public static final int analog_outputs = 2130903053;
        public static final int custom_dialog_title_bar = 2130903054;
        public static final int device_interface_module = 2130903055;
        public static final int device_name = 2130903056;
        public static final int digital_device = 2130903057;
        public static final int digital_devices = 2130903058;
        public static final int file_info = 2130903059;
        public static final int header = 2130903060;
        public static final int i2c_device = 2130903061;
        public static final int i2cs = 2130903062;
        public static final int info_button = 2130903063;
        public static final int legacy = 2130903064;
        public static final int matrices = 2130903065;
        public static final int matrix_devices = 2130903066;
        public static final int motors = 2130903067;
        public static final int orange_warning = 2130903068;
        public static final int pwm_device = 2130903069;
        public static final int pwms = 2130903070;
        public static final int servo = 2130903071;
        public static final int servos = 2130903072;
        public static final int shape = 2130903073;
        public static final int simple_device = 2130903074;
    }

    /* renamed from: com.qualcomm.ftcdriverstation.R.menu */
    public static final class menu {
        public static final int ftc_driver_station = 2131427328;
    }

    /* renamed from: com.qualcomm.ftcdriverstation.R.string */
    public static final class string {
        public static final int about_activity = 2131361792;
        public static final int action_configuration = 2131361793;
        public static final int action_exit_app = 2131361794;
        public static final int action_restart_robot = 2131361795;
        public static final int action_settings = 2131361796;
        public static final int action_wifi_channel_selector = 2131361797;
        public static final int add_motor_controller_menu_item = 2131361798;
        public static final int add_servo_controller_menu_item = 2131361799;
        public static final int app_name = 2131361800;
        public static final int attached = 2131361801;
        public static final int autoconfigure = 2131361802;
        public static final int autoconfigureLaunch_text = 2131361803;
        public static final int autoconfigure_menu_item = 2131361804;
        public static final int cancel = 2131361805;
        public static final int choice_prompt = 2131361806;
        public static final int choice_prompt_analogInput = 2131361807;
        public static final int choice_prompt_analogOutput = 2131361808;
        public static final int choice_prompt_digital_device = 2131361809;
        public static final int choice_prompt_i2c = 2131361810;
        public static final int configure_activity = 2131361811;
        public static final int configure_menu_item = 2131361812;
        public static final int configure_settings = 2131361813;
        public static final int default_port = 2131361814;
        public static final int device_info = 2131361815;
        public static final int device_type = 2131361816;
        public static final int dialog_title_select_op_mode = 2131361817;
        public static final int done_button = 2131361818;
        public static final int edit_analog_input_devices_activity = 2131361819;
        public static final int edit_analog_output_devices_activity = 2131361820;
        public static final int edit_controller = 2131361821;
        public static final int edit_core_device_interface_module_controller_activity = 2131361822;
        public static final int edit_digital_devices_activity = 2131361823;
        public static final int edit_i2c_devices_activity = 2131361824;
        public static final int edit_legacy_module_controller_activity = 2131361825;
        public static final int edit_matrix_controller_activity = 2131361826;
        public static final int edit_motor_controller_activity = 2131361827;
        public static final int edit_motor_controller_menu_item = 2131361828;
        public static final int edit_pwm_devices_activity = 2131361829;
        public static final int edit_servo_controller_activity = 2131361830;
        public static final int file_activate_button = 2131361831;
        public static final int file_delete_button = 2131361832;
        public static final int file_edit_button = 2131361833;
        public static final int file_prompt = 2131361834;
        public static final int filename_editText = 2131361835;
        public static final int gamepad_android_standard = 2131361836;
        public static final int gamepad_default = 2131361837;
        public static final int gamepad_logitech_f310 = 2131361838;
        public static final int gamepad_microsoft_xbox_360 = 2131361839;
        public static final int input_name_hint = 2131361840;
        public static final int input_name_label = 2131361841;
        public static final int k9LegacyBot = 2131361842;
        public static final int k9USBBot = 2131361843;
        public static final int label_current_op_mode = 2131361844;
        public static final int label_loading_op_mode = 2131361845;
        public static final int label_queued_op_mode = 2131361846;
        public static final int label_select = 2131361847;
        public static final int label_start = 2131361848;
        public static final int label_start_timed = 2131361849;
        public static final int label_stop = 2131361850;
        public static final int launch_wifi_settings = 2131361851;
        public static final int legacy_controller_name = 2131361852;
        public static final int load_menu_item = 2131361853;
        public static final int matrix_controller_name = 2131361854;
        public static final int matrix_controller_name_prompt = 2131361855;
        public static final int matrix_motor_title = 2131361856;
        public static final int matrix_name_prompt = 2131361857;
        public static final int matrix_port0 = 2131361858;
        public static final int matrix_port1 = 2131361859;
        public static final int matrix_port2 = 2131361860;
        public static final int matrix_port3 = 2131361861;
        public static final int matrix_port4 = 2131361862;
        public static final int matrix_port5 = 2131361863;
        public static final int matrix_port6 = 2131361864;
        public static final int matrix_port7 = 2131361865;
        public static final int matrix_servo_title = 2131361866;
        public static final int motor_controller_name = 2131361867;
        public static final int motor_controller_name_text = 2131361868;
        public static final int motor_name = 2131361869;
        public static final int motor_name_prompt = 2131361870;
        public static final int motor_port1 = 2131361871;
        public static final int motor_port2 = 2131361872;
        public static final int name_prompt_text = 2131361873;
        public static final int name_prompt_undertext = 2131361874;
        public static final int pair_instructions = 2131361875;
        public static final int pair_wifi_direct = 2131361876;
        public static final int pair_wifi_direct_menu_item = 2131361877;
        public static final int ping_label = 2131361878;
        public static final int port = 2131361879;
        public static final int pref_change_wifi_channel = 2131361880;
        public static final int pref_configure_robot_title = 2131361881;
        public static final int pref_driver_station_mac = 2131361882;
        public static final int pref_driver_station_mac_default = 2131361883;
        public static final int pref_gamepad_title = 2131361884;
        public static final int pref_gamepad_user1_type_key = 2131361885;
        public static final int pref_gamepad_user1_type_title = 2131361886;
        public static final int pref_gamepad_user2_type_key = 2131361887;
        public static final int pref_gamepad_user2_type_title = 2131361888;
        public static final int pref_hardware_config_filename = 2131361889;
        public static final int pref_launch_autoconfigure = 2131361890;
        public static final int pref_launch_configure = 2131361891;
        public static final int pref_launch_settings = 2131361892;
        public static final int pref_log_network_traffic_key = 2131361893;
        public static final int pref_log_network_traffic_summary = 2131361894;
        public static final int pref_log_network_traffic_title = 2131361895;
        public static final int pref_logging_title = 2131361896;
        public static final int pref_pair_rc_summary = 2131361897;
        public static final int pref_pair_rc_title = 2131361898;
        public static final int pref_wifi_channel_selection_title = 2131361899;
        public static final int pref_wifi_config_title = 2131361900;
        public static final int readXML_text = 2131361901;
        public static final int restore_settings = 2131361902;
        public static final int row_port0 = 2131361903;
        public static final int row_port1 = 2131361904;
        public static final int row_port2 = 2131361905;
        public static final int row_port3 = 2131361906;
        public static final int row_port4 = 2131361907;
        public static final int row_port5 = 2131361908;
        public static final int row_port6 = 2131361909;
        public static final int save_button = 2131361910;
        public static final int save_configuration = 2131361911;
        public static final int scan = 2131361912;
        public static final int scanButton_text = 2131361913;
        public static final int servo_controller_name = 2131361914;
        public static final int servo_controller_name_prompt = 2131361915;
        public static final int servo_name_prompt = 2131361916;
        public static final int settings_activity = 2131361917;
        public static final int titleText_view = 2131361918;
        public static final int title_activity_autoconfigure = 2131361919;
        public static final int title_activity_config_wifi_direct = 2131361920;
        public static final int title_activity_load = 2131361921;
        public static final int title_activity_settings = 2131361922;
        public static final int title_activity_wifi_channel_selector = 2131361923;
        public static final int user1_label = 2131361924;
        public static final int user2_label = 2131361925;
        public static final int view_logs_activity = 2131361926;
        public static final int wifi_direct_device_none = 2131361927;
        public static final int wifi_direct_devices = 2131361928;
        public static final int wifi_direct_label = 2131361929;
        public static final int wifi_direct_update_settings = 2131361930;
        public static final int writeXML_prompt = 2131361931;
        public static final int writeXML_text = 2131361932;
    }

    /* renamed from: com.qualcomm.ftcdriverstation.R.style */
    public static final class style {
        public static final int AppBaseTheme = 2131165184;
        public static final int AppTheme = 2131165185;
        public static final int CustomAlertDialog = 2131165186;
        public static final int RobotoButtonStyle = 2131165187;
        public static final int RobotoTextViewStyle = 2131165188;
        public static final int Theme_CustomizedFullScreen = 2131165189;
    }

    /* renamed from: com.qualcomm.ftcdriverstation.R.xml */
    public static final class xml {
        public static final int preferences = 2131034112;
    }
}
